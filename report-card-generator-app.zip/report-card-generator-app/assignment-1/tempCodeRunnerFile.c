printf("Enter The STANDARD(CLASS) Of the Student :      ");
    // scanf("%d ",&studentClass);